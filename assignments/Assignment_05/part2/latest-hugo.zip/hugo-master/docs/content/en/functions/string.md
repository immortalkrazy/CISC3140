---
title: string
# linktitle: string
description: Creates a string from the argument passed to the function
godocref:
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [strings]
signature: ["string INPUT"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---

* `{{string "BatMan"}}` → "BatMan"

