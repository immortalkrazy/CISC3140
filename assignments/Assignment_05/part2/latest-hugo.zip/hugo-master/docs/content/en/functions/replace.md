---
title: replace
# linktitle: replace
description: Replaces all occurrences of the search string with the replacement string.
godocref:
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: []
signature: ["replace INPUT OLD NEW"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---

```
`{{ replace "Batman and Robin" "Robin" "Catwoman" }}`
→ "Batman and Catwoman"
```

