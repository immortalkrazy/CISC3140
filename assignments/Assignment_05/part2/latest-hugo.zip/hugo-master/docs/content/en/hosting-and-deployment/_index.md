---
title: Hosting & Deployment
linktitle: Hosting & Deployment Overview
description: Site builds, automated deployments, and popular hosting solutions.
date: 2016-11-01
publishdate: 2016-11-01
lastmod: 2016-11-01
categories: [hosting and deployment]
keywords: []
menu:
  docs:
    parent: "hosting-and-deployment"
    weight: 01
weight: 01	#rem
draft: false
aliases: []
toc: false
---

Because Hugo renders *static* websites, you can host your new Hugo website virtually anywhere. The following represent only a few of the more popular hosting and automated deployment solutions used by the Hugo community.
