---
name: Support (Do not use)
about: Please do not use Github for support requests. Visit https://discourse.gohugo.io for support
title: ''
labels: support
assignees: ''

---

Issues created with this template will be automatically closed. Please visit https://discourse.gohugo.io for the support you really, really, want!