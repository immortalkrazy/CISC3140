---
name: Proposal
about: Suggest an idea for Hugo
title: ''
labels: 'Proposal'
assignees: ''

---
